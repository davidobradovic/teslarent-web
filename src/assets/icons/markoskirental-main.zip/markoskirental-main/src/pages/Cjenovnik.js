import React from 'react'

function Cjenovnik() {
  return (
    <div style={{ width: '100vw', minHeight: '100vh', backgroundColor: '#0f3773', color: 'white', padding: 25 }}>
      <h1 className='uppercase text-center font-semibold text-2xl'>Cjenovnik</h1>
      <div className="odraslimeni">
        <h3 className='uppercase text-sm uppercase pb-2'>Meni za odrasle</h3>
        <table className='w-full' style={{ backgroundColor: '#1f447a' }}>
          <thead className='w-full'>
            <tr className='w-full border-b-2'>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Artikal</th>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Trajanje</th>
              <th className='text-left text-sm uppercase p-3'>Cijena</th>
            </tr>
          </thead>
          <tbody className='w-full'>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet Ski Oprema (Skije, Pancerice, Stapovi)</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>20 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet Ski Oprema (Skije, Pancerice, Stapovi)</td>
              <td className='text-xs uppercase border-r-2 p-3'>4+ DANA</td>
              <td className='text-xs uppercase p-3'>15 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Skije + Stapovi</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>13 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Pancerice za odrasle (Cipele za odrasle)</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>7 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Stapovi</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>3 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet snowboard oprema</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>25 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet snowboard oprema</td>
              <td className='text-xs uppercase border-r-2 p-3'>4+ DANA</td>
              <td className='text-xs uppercase p-3'>25 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Snowboard Daska</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>15 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Snowboard Cipele</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>10 KM</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="djecijimeni mt-5">
        <h3 className='uppercase text-sm uppercase pb-2'>Meni za djecu</h3>
        <table className='w-full' style={{ backgroundColor: '#1f447a' }}>
          <thead className='w-full'>
            <tr className='w-full border-b-2'>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Artikal</th>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Trajanje</th>
              <th className='text-left text-sm uppercase p-3'>Cijena</th>
            </tr>
          </thead>
          <tbody className='w-full'>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet Ski Oprema (Skije, Pancerice, Stapovi)</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>12 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet Ski Oprema (Skije, Pancerice, Stapovi)</td>
              <td className='text-xs uppercase border-r-2 p-3'>4+ DANA</td>
              <td className='text-xs uppercase p-3'>10 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Djecije skije + stapovi za djecu</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>9 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Pancerice za djecu (cipele za djecu)</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>5 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet snowboard oprema</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>12 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Komplet snowboard oprema</td>
              <td className='text-xs uppercase border-r-2 p-3'>4+ DANA</td>
              <td className='text-xs uppercase p-3'>10 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Snowboard Daska</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>9 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Snowboard Cipele</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>5 KM</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="djecijimeni mt-5">
        <h3 className='uppercase text-sm uppercase pb-2'>Dodatni meni</h3>
        <table className='w-full' style={{ backgroundColor: '#1f447a' }}>
          <thead className='w-full'>
            <tr className='w-full border-b-2'>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Artikal</th>
              <th className='text-left text-sm uppercase p-3 border-r-2'>Trajanje</th>
              <th className='text-left text-sm uppercase p-3'>Cijena</th>
            </tr>
          </thead>
          <tbody className='w-full'>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Kaciga</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>4 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Brile</td>
              <td className='text-xs uppercase border-r-2 p-3'>4+ DANA</td>
              <td className='text-xs uppercase p-3'>3 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Sanke</td>
              <td className='text-xs uppercase border-r-2 p-3'>1 DAN</td>
              <td className='text-xs uppercase p-3'>7 KM</td>
            </tr>
            <tr className='w-full border-b-2'>
              <td className='text-xs uppercase border-r-2 p-3'>Motorne sanke</td>
              <td className='text-xs uppercase border-r-2 p-3'>30 min</td>
              <td className='text-xs uppercase p-3'>60 KM</td>
            </tr>
            
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Cjenovnik
