import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { HiOutlineMenuAlt3 } from "react-icons/hi";
import { IoCloseOutline } from "react-icons/io5";
import { TiWeatherCloudy, TiWeatherDownpour, TiWeatherShower, TiWeatherPartlySunny } from 'react-icons/ti'
import { WiHumidity } from 'react-icons/wi'
import { LuWind } from 'react-icons/lu'
import { BsArrowUpCircle } from 'react-icons/bs'


function Home() {

    const [mobileMenu, setMobileMenu] = React.useState(null)
    const [data, setData] = useState([])
    const [lat, setLat] = useState([]);
    const [long, setLong] = useState([]);

    const handleMobileMenu = () => {
        mobileMenu ? setMobileMenu(null) : setMobileMenu(true)
    }

    const navigate = useNavigate();

    async function fetchWeather() {
        await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=43.733422&lon=18.560291&units=metric&appid=4af5b5c76f3c71029b4239f0ea7db62f`)
            .then(res => res.json())
            .then(result => {
                setData(result)
            });
    }
    const checkWeather = data.weather && data.weather[0] && data.weather[0].main

    useEffect(() => {
        navigator.geolocation.getCurrentPosition(function (position) {
            setLat(position.coords.latitude);
            setLong(position.coords.longitude);
        });
        fetchWeather()
    }, [lat, long]);


    return (
        <div>
            <header className='fixed p-3 top-0 left-0 flex items-center justify-between' style={{ height: 100, backgroundColor: 'rgba(0,0,0,0.5)', width: '100vw', zIndex: 999999, backdropFilter: 'blur(15px)' }}>
                <img style={{ height: 80 }} src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385896/topc/nslc6wqaxhv2sc5uue8w.png" alt="" />
                <nav className={`flex items-center ${mobileMenu ? 'phonenav' : null}`} style={{ gap: 20 }}>
                    <a href='#onama' className='uppercase text-white font-regular'>O nama</a>
                    <a href='#gallery' className='uppercase text-white font-regular'>Galerija</a>
                    <a href='#contact' className='uppercase text-white font-regular'>Kontakt</a>
                    <Link to='/cjenovnik' className='uppercase text-white font-regular'>Cjenovnik</Link>
                </nav>
                <button onClick={handleMobileMenu} className='menu-button rounded flex items-center justify-center absolute' style={{ width: 35, height: 35, backgroundColor: '#0F3D84' }}>
                    {
                        mobileMenu ? (<IoCloseOutline color='white' size={21} />) : (<HiOutlineMenuAlt3 color='white' size={21} />)
                    }
                </button>
            </header>
            <section style={{ width: '100vw', height: '100vh', backgroundImage: `url("https://res.cloudinary.com/dxo3z5off/image/upload/v1706385899/topc/k8ovbwuunljthktpwyqe.png")`, backgroundPosition: 'center', backgroundSize: 'cover', backgroundRepeat: 'no-repeat' }} className='flex items-center justify-center relative'>
                <h1 style={{ fontSize: 36, fontWeight: '700', stroke: '#156adc' }} className='main-section-title text-center w-10/12'>Osvježite svoje skijaško iskustvo s Ski Rental Stefan na Jahorini - vrhunska oprema i usluga koja će ispuniti sve vaše potrebe na stazi.</h1>
                <div style={{ width: '70%', height: 100, bottom: -50 }} className="absolute bg-gray-100 flex items-center justify-around px-4">
                    {data && data.main ? (
                        <>
                            {checkWeather === "Clear" ? (
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                    <TiWeatherPartlySunny size={25} /> {data.main.temp.toFixed(0)} °C
                                </h1>
                            ) : checkWeather === "Snow" ? (
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                    <TiWeatherShower size={25} /> {data.main.temp.toFixed(0)} °C
                                </h1>
                            ) : checkWeather === "Rain" ? (
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                    <TiWeatherDownpour size={25} /> {data.main.temp.toFixed(0)} °C
                                </h1>
                            ) : checkWeather === "Sunny" ? (
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                    <TiWeatherCloudy size={25} /> {data.main.temp.toFixed(0)} °C
                                </h1>
                            ) : (
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                    <TiWeatherCloudy size={25} /> {data.main.temp.toFixed(0)} °C
                                </h1>
                            )}
                            <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex flex-col items-center gap-3'>
                                <WiHumidity size={25} /> {data.main.humidity} %
                            </h1>
                            <div className='flex flex-col gap-3 items-center'>
                                <BsArrowUpCircle color='#0F3D84' size={25} style={{ rotate: `${data.wind.deg}deg` }} />
                                <h1 style={{ color: '#0F3D84' }} className='font-light text-sm flex items-center gap-2'>
                                    <LuWind size={18} /> {data.wind.speed.toFixed(0)} km/h
                                </h1>
                            </div>
                        </>
                    ) : null}
                </div>
            </section>
            <section id='onama' className='px-5 text-white' style={{ marginTop: 75, backgroundColor: '#0F3D84' }}>
                <h1 style={{ fontSize: 30 }} className='text-center py-5'>O nama</h1>
                <p className='pb-5'>Dobrodošli u Ski Rental Stefan, vašu vrhunsku destinaciju za skijaško uživanje na Jahorini! Smješteni smo na atraktivnom djelu Jahorine odmah pored puta, čime vam pružamo jednostavan pristup vrhunskom skijanju i udobnosti. Naša usluga uključuje i besplatan prevoz do našeg ski rentala, čineći vaše iskustvo još praktičnijim.
                    <br />
                    <br />
                    U ponudi imamo najpoznatije brendove skijaške opreme kako biste maksimalno uživali na stazi. Bilo da ste početnik ili iskusni skijaš, naša široka paleta opreme uključuje brendove poput <strong>FISCHER, HEAD, ELAN, VOLKL, ATOMIC</strong> i mnoge druge. Vaše skijaško iskustvo je naš prioritet, stoga smo posvećeni pružanju vrhunske opreme koja odgovara vašim potrebama.
                    <br />
                    <br />
                    <strong>Spremni smo vam pružiti nezaboravan boravak na Jahorini, uz vrhunsku opremu i uslugu. Očekujemo vas u Ski Rental Stefan, vašem partneru za nezaboravno skijanje na ovoj predivnoj planini.</strong></p>
            </section>
            <section id='gallery' className="gallery">
                <h1 style={{ fontSize: 30 }} className='text-center py-5'>Galerija</h1>
                <div style={{ gap: 10 }} className="px-3 gallery-images flex flex-wrap pb-3">
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385910/topc/d9zwameqbuqsq1r6jgks.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385910/topc/itruaok2htl4gjgukzrp.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385910/topc/puwc68knxzyszgsjmswe.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385910/topc/ivtpkwibk0tpugwwvywk.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385910/topc/l1ksqisnbsk1lyfznuux.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385911/topc/mzumukznkvlcx4h9pmdh.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385911/topc/rqspyqknx0powvpkfc6i.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385911/topc/bs3v66af9ds9w0bwxpet.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385911/topc/jy0ifab7gvlytcel2m3b.jpg" alt="" />
                    <img style={{ width: 'calc(100% / 4 - 7.5px)' }} loading="lazy" src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385917/topc/tjpmr157isnutxo5vtzs.jpg" alt="" />
                </div>
            </section>
            <section id='contact' style={{ height: 350 }} className="contact flex items-center mx-3 mb-3 bg-gray-200">
                <div style={{ backgroundColor: '#0F3D84' }} className="h-full contactdetails w-full text-white p-3 flex flex-col items-start justify-between">
                    <div style={{ gap: 10 }} className='flex flex-col'>
                        <h1 style={{ fontSize: 22 }} className='uppercase font-light'>Kontaktirajte nas</h1>
                        <a className='font-light' style={{ fontSize: 15 }} href='tel+38765236460'>Tel: +387 65 236 460</a>
                        <a className='font-light' style={{ fontSize: 15 }} href='mailto:info@skirentalstefan.com'>Mail: info@skirentalstefan.com</a>
                        <h3 style={{ fontSize: 15 }} className='font-bold'>Radno vrijeme:</h3>
                        <h3 style={{ fontSize: 13 }} className='font-light'>Svaki dan: 8:30 - 16:30</h3>
                    </div>
                    <div style={{ height: 5, backgroundColor: 'rgba(255,255,255,0.15)' }} className="line w-full rounded-full"></div>
                    <p style={{ fontSize: 17 }}>Za sva pitanja i rezervacije, slobodno nas kontaktirajte! Vaš Ski Rental Stefan je ovdje da osigura vaše savršeno skijaško iskustvo na Jahorini. Radujemo se vašem pozivu ili poruci!</p>
                </div>
            </section>
            <button onClick={() => navigate('/cjenovnik')} style={{ backgroundColor: '#0F3D84' }} className='pogledajcjenovnik p-3 uppercase text-white'>Pogledaj cjenovnik</button>
        </div>
    )
}

export default Home