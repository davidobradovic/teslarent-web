import React, { useEffect, useState } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Cjenovnik from './pages/Cjenovnik'

function App() {

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 3000)
  }, [])

  return (
    <BrowserRouter>
      {
        loading ? (
          <div style={{ height: '100vh', width: '100vw', backgroundColor: 'white' }} className='flex items-center justify-center'>
            <section><span class="loader-1"></span></section>
            <img loading="lazy" className='loader-image' src="https://res.cloudinary.com/dxo3z5off/image/upload/v1706385896/topc/nslc6wqaxhv2sc5uue8w.png" alt="" />
          </div>
        ) : (
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/cjenovnik' element={<Cjenovnik />} />
          </Routes>
        )
      }
    </BrowserRouter>
  )
}

export default App